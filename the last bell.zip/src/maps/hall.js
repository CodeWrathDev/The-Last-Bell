import { T } from '../assets/TextureFactory.js';
import { MapBuilder } from './MapBuilder.js';
import { TILE } from '../config.js';

const px = (t) => t * TILE;

/**
 * Main school junction. The old version was a straight hallway with every
 * room on one wall. This version is a 52x19 four-wing junction: a long
 * central route stays readable, while north/south arcades, a central atrium
 * and several loops let the player approach rooms from different directions.
 */
export function buildHall() {
  const W = 52, H = 19;
  const m = new MapBuilder('hall', W, H, T.WALLINT);
  m.meta = {
    name: 'Main Building – Four-Wing Junction', outdoor: false, rain: false,
    ambient: 0.86, bgm: 'hum', fluorescent: true, ghostDelay: 12,
    ghostPatrol: [[3, 5], [13, 5], [25, 5], [38, 5], [48, 5], [8, 3], [24, 3], [37, 9], [47, 11]],
    zoom: 2, apparition: { ends: [[3, 5], [48, 5]], delay: 34 },
  };

  // Outer shell.
  m.rect('ground', 0, 0, W, 1, T.WALLINT);
  m.rect('ground', 0, H - 1, W, 1, T.WALLINT);
  m.rect('ground', 0, 1, 1, H - 2, T.WALLINT);
  m.rect('ground', W - 1, 1, 1, H - 2, T.WALLINT);

  // Main route, four north branches, four south branches and a broad atrium.
  m.rect('ground', 2, 5, W - 4, 2, T.FLOOR);
  for (const [x, w] of [[5, 10], [18, 12], [32, 11], [44, 6]]) m.rect('ground', x, 2, w, 4, T.FLOOR);
  for (const x of [8, 24, 37, 46]) m.rect('ground', x, 3, 2, 5, T.FLOOR);
  for (const [x, w] of [[3, 11], [16, 14], [31, 10], [44, 6]]) m.rect('ground', x, 6, w, 11, T.FLOOR);
  for (const x of [8, 22, 28, 37, 46]) m.rect('ground', x, 6, 2, 6, T.FLOOR);
  m.rect('ground', 21, 4, 9, 10, T.FLOOR); // central atrium / cross-over
  // Each wing has a slightly different school-era floor finish instead of
  // repeating one texture across the whole hall.
  m.rect('ground', 5, 2, 10, 1, T.FLOORTILE);
  m.rect('ground', 18, 2, 12, 1, T.FLOORDARK);
  m.rect('ground', 32, 2, 11, 1, T.LIBFLOOR);
  m.rect('ground', 22, 7, 7, 6, T.RUG);
  m.rect('ground', 31, 9, 10, 1, T.FLOORTILE);
  // Keep the upper edge of the main route walkable: the player and crawler
  // bodies are centred on row 5 and need one tile of clearance above them.
  m.rect('ground', 2, 4, 48, 1, T.FLOOR);
  for (const [x, w] of [[5, 10], [18, 12], [32, 11], [44, 6]]) m.rect('ground', x, 4, w, 1, T.FLOOR);
  for (const [x, w] of [[3, 11], [16, 14], [31, 10], [44, 6]]) m.rect('ground', x, 7, w, 1, T.FLOOR);

  // Damp tiles and old school markings make each route readable in the dark.
  for (const [x, y] of [[4, 5], [15, 6], [19, 5], [30, 6], [35, 5], [42, 6], [10, 10], [27, 11], [38, 14], [47, 14]]) m.set('ground', x, y, T.FLOORCRACK);
  for (const [x, y] of [[6, 3], [13, 4], [20, 3], [29, 4], [34, 3], [41, 4], [4, 14], [14, 9], [33, 10], [48, 8]]) m.set('ground', x, y, T.FLOORSTAIN);

  // Pillars and lockers divide sight lines without blocking the routes.
  for (const [x, y] of [[16, 4], [20, 8], [30, 8], [43, 8], [14, 12], [31, 12], [42, 12]]) m.set('deco', x, y, T.PILLAR);
  for (const [x, y] of [[3, 4], [15, 4], [33, 4], [49, 4], [3, 8], [14, 8], [32, 8], [49, 8]]) m.set('deco', x, y, T.SHELF);

  // Doors are distributed around the wings instead of lined up on one wall.
  const door = (d) => {
    const y = d.side === 'N' ? 1 : 17;
    const w = d.w ?? 2;
    m.rect('deco', d.x, y, w, 1, d.locked ? T.DOORLOCK : T.DOOR);
    const base = { x: px(d.x), y: px(y), w: px(w), h: px(1), label: d.label, ...(d.plate ? { plate: d.plate } : {}), target: d.target, spawn: d.spawn || 'fromHall', ...(d.chapter ? { chapter: d.chapter } : {}) };
    if (d.locked) m.addObject({ ...base, type: 'lockeddoor', id: d.id, tileX: d.x, tileY: y, needsFlags: d.flags || [], text: d.hint || 'It will not budge.' });
    else m.addObject({ ...base, type: 'door' });
  };

  door({ x: 7, side: 'N', target: 'classroomA', label: 'Classroom 10A' });
  door({ x: 19, side: 'N', target: 'classroomB', label: 'Classroom 10B', locked: true, id: 'door_9', flags: ['has_key_10b'], hint: 'Classroom 10B is locked. The key was left in 10A.' });
  door({ x: 33, side: 'N', target: 'library', label: 'Library', locked: true, id: 'door_20', flags: ['power_on'], hint: 'The Library lock has no power. Restore the electrical panel first.' });
  door({ x: 45, side: 'N', target: 'stairs', label: 'Stairwell', chapter: 'ch2' });

  door({ x: 4, side: 'S', target: 'toilets', label: 'Toilets', chapter: 'ch2' });
  door({ x: 21, side: 'S', target: 'auditorium', label: 'Assembly hall', chapter: 'ch3', locked: true, id: 'door_assembly', flags: ['power_on'], hint: 'A faded red sign says ASSEMBLY HALL. The electric lock is dead.' });
  door({ x: 30, side: 'S', target: 'office', label: 'School Office', locked: true, id: 'door_26', flags: ['has_office_key'], hint: 'A brass lock holds the School Office. The key is somewhere in the Library.' });
  door({ x: 46, side: 'S', target: 'campus', label: 'Back to courtyard' });

  // Existing spawn names stay compatible, but now place the player at different wings.
  m.spawns = {
    fromCampus: { x: px(25) + 16, y: px(4) + 24 },
    fromClassroomA: { x: px(8) + 16, y: px(4) + 24 },
    fromClassroomB: { x: px(20) + 16, y: px(4) + 24 },
    fromLibrary: { x: px(34) + 16, y: px(4) + 24 },
    fromOffice: { x: px(31) + 16, y: px(15) + 24 },
    fromToilets: { x: px(5) + 16, y: px(15) + 24 },
    fromStairs: { x: px(46) + 16, y: px(4) + 24 },
    fromAuditorium: { x: px(22) + 16, y: px(15) + 24 },
    start: { x: px(25) + 16, y: px(5) + 24 },
  };

  // Door plates already carry the room names. Do not add a second class/wing
  // sign layer here: it duplicated labels and the low signs were hidden by
  // the first-person camera. Use different wall props for visual variety.
  const wall = (sprite, x, y) => m.addObject({ type: 'decor', sprite, x: px(x) + 16, y: px(y) + 4, w: 0, h: 0, blocks: false, depth: 'wall', oy: 0 });
  wall('timetable', 3, 2);
  wall('poster', 15, 2);
  wall('calendar', 29, 2);
  wall('mirror', 41, 2);
  wall('emergency_light', 2, 7);
  wall('poster', 43, 7);
  m.addObject({ type: 'note', x: px(23), y: px(8), w: px(3), h: px(1), text: 'A hand-drawn evacuation map. The arrows do not agree with the walls. Someone has circled three routes in red.' });
  m.addObject({ type: 'note', x: px(39), y: px(10), w: px(2), h: px(1), text: 'A lost timetable: WEST WING, EAST WING, BASEMENT, ROOF. The last period has no room number.' });
  // This is a readable floor note, not an interactive clock prop. The old
  // clock sprite made the E prompt look like a clock instead of a document.
  m.addObject({ type: 'note', x: px(25), y: px(9), w: px(2), h: px(1), sprite: 'item_note', text: 'A maintenance note: "The atrium clock ticks backwards whenever the lights flicker."' });
  for (const [x, y] of [[10, 6], [16, 6], [27, 6], [39, 6], [47, 6], [10, 13], [17, 13], [28, 13], [39, 13]]) m.addObject({ type: 'decor', sprite: 'bench', x: px(x), y: px(y), w: px(2), h: px(1), blocks: false });
  for (const [x, y] of [[6, 5], [12, 5], [24, 5], [35, 5], [46, 5], [8, 10], [24, 10], [37, 10], [47, 10]]) m.addObject({ type: 'light', x: px(x) + 16, y: px(y), light: 118, flicker: (x + y) % 3 === 0, tube: [px(x), y] });
  for (const [x, y] of [[2, 5], [49, 5], [21, 9], [30, 9]]) m.addObject({ type: 'light', x: px(x) + 16, y: px(y), light: 62, tint: 0xff3030, intensity: 0.52, pulse: true });

  return m;
}
